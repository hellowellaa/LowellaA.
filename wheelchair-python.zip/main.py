#!/usr/bin/env python3
import serial
import time
import requests
import warnings

warnings.simplefilter("ignore")

previous = ""

if __name__ == '__main__':
    ser = serial.Serial('/dev/cu.usbserial-2110', 9600, timeout=1)
    ser.reset_input_buffer()


    while True:
        try:
            r = requests.get('https://wheelchair.iconicsocietyofficial.com/getMovement', verify=False, stream=True)
            res = r.json()
            movement = res['current_movement']
            print("movement: {}".format(movement))
            print("previous: {}".format(previous))
            if movement == "up" and previous != "forward":
                print("Moving forward")
                ser.write(b"forward\n")
                line = ser.readline().decode('utf-8').rstrip()
                print(line)
                previous = "forward"
            elif movement == "left" and previous != "left":
                ser.write(b"left\n")
                line = ser.readline().decode('utf-8').rstrip()
                print(line)
                previous = "left"
            elif movement == "right" and previous != "right":
                ser.write(b"right\n")
                line = ser.readline().decode('utf-8').rstrip()
                print(line)
                previous = "right"
            elif movement == "Stop" and previous != "stop":
                print("Stopping")
                ser.write(b"close\n")
                line = ser.readline().decode('utf-8').rstrip()
                print(line)
                previous = "stop"
        except Exception:
        
            print("Error")
            continue
            
        
